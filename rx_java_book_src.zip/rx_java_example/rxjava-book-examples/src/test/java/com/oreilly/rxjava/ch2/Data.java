package com.oreilly.rxjava.ch2;

class Data {
}
