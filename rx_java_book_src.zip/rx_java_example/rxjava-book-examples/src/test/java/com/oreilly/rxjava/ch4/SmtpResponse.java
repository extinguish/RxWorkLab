package com.oreilly.rxjava.ch4;

class SmtpResponse {
}
