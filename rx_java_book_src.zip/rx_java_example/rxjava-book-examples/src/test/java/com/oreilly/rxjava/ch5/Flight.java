package com.oreilly.rxjava.ch5;

class Flight {
}
