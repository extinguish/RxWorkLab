package com.oreilly.rxjava.ch3;

class LicensePlate {
}
