package com.oreilly.rxjava.ch4;

class Book {
	public String getTitle() {
		return "Title";
	}
}
