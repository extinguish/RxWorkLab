package com.oreilly.rxjava.ch8;

class Person {

	int getAge() {
		return 42;
	}

	String getFirstName() {
		return "Smith";
	}

}
