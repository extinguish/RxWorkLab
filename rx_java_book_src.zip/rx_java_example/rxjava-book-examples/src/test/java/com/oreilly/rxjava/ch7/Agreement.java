package com.oreilly.rxjava.ch7;

class Agreement {
	boolean postalMailRequired() {
		return true;
	}
}
