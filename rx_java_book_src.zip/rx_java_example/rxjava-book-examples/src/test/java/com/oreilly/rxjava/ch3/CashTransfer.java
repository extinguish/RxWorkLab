package com.oreilly.rxjava.ch3;

import java.math.BigDecimal;

class CashTransfer {

	BigDecimal getAmount() {
		return BigDecimal.ONE;
	}

}
