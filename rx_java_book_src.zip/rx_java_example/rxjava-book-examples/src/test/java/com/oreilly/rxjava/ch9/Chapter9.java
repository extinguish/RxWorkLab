package com.oreilly.rxjava.ch9;

import org.junit.Ignore;

@Ignore
public class Chapter9 {

	//no samples in this chapter

}
