package com.oreilly.rxjava.ch3;

enum City {

	Warsaw, London, Paris, NewYork

}
