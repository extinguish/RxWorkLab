package com.oreilly.rxjava.ch8;

import java.util.List;

public class Cities {
    private List<City> results;

    public List<City> getResults() {
        return results;
    }

    public void setResults(List<City> results) {
        this.results = results;
    }
}

