package com.oreilly.rxjava.ch7;

class Confirmation {
}
