package com.oreilly.rxjava.ch8;

class Insurance {
}
