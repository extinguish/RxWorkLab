package com.oreilly.rxjava.ch8;

class Incident {
	boolean isHIghPriority() {
		return true;
	}
}
